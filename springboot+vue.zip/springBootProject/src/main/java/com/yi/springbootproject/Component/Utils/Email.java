package com.yi.springbootproject.Component.Utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class Email {
    private final JavaMailSender javaMailSender;

    public Email(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Value("${spring.mail.username}")
    private String fromEmail;

    public String sendEmail(String toEmail) {
        String verity = verity();
        SimpleMailMessage smm = new SimpleMailMessage();
        smm.setFrom(fromEmail);
        smm.setTo(toEmail);
        smm.setSubject("联合影院");
        smm.setText("感谢注册，验证码：" + verity+"\n有效时长为2分钟");
        javaMailSender.send(smm);
        return verity;
    }

    private String verity() {
        Random r = new Random();
        StringBuilder ver = new StringBuilder();
        for (int j = 0; j < 4; j++) {
            int a = r.nextInt(10);
            ver.append(a);
        }
        return ver.toString();
    }
}
