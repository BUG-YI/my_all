package com.yi.springbootproject.Component.Utils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class Q {
    @GetMapping(value = "/QR",produces = MediaType.IMAGE_PNG_VALUE)
    public void RQR(
            @RequestParam String content,
            @RequestParam int width,
            @RequestParam int height,
            HttpServletResponse resp
    )throws Exception{
        QRCodeWriter qrw=new QRCodeWriter();
        Map<EncodeHintType,Object>hints=new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET,"utf-8");
        BitMatrix bitMatrix=qrw.encode(
                content, BarcodeFormat.QR_CODE,
                width,height,hints
        );
        resp.setContentType(MediaType.IMAGE_PNG_VALUE);
        OutputStream out=resp.getOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix,"png",out);
        out.close();
    }
}
