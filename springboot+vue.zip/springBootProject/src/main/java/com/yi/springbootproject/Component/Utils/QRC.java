package com.yi.springbootproject.Component.Utils;

import com.google.zxing.EncodeHintType;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class QRC {
    /**
     * @param content 文本内容，连接等
     * @param width height 二维码宽，高
     * @param resp 响应
     * @throws Exception 抛出异常
     */

    // produces 返回内容类型
    @GetMapping(value = "/createQRC",produces = MediaType.IMAGE_PNG_VALUE)
    public void cQRC(
            @RequestParam(defaultValue = "https://www.baidu.com") String content,
            @RequestParam(defaultValue = "200")int width,
            @RequestParam(defaultValue = "200")int height,
            HttpServletResponse resp)throws Exception{
        QRCodeWriter QRCw=new QRCodeWriter();
        Map<EncodeHintType,Object> hints =new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET,"utf-8");

        BitMatrix bitMatrix=QRCw.encode(
                content,
                BarcodeFormat.QR_CODE,
                width,
                height,
                hints
        );
        resp.setContentType(MediaType.IMAGE_PNG_VALUE);
        OutputStream out=resp.getOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix,"PNG",out);
        out.close();
     }
}
