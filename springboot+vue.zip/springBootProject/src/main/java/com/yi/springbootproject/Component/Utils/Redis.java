package com.yi.springbootproject.Component.Utils;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

@Component
public class Redis {
    private final RedisTemplate<String,Object>redisTemplate;

    public Redis(RedisTemplate<String, Object> redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public void set(String key,Object value){
        redisTemplate.opsForValue().set(key, value);
    }

    public void set(String key,Object value,Long timeout){
        redisTemplate.opsForValue().set(key, value,timeout, TimeUnit.SECONDS);
    }

    public Object get(String key){
        return redisTemplate.opsForValue().get(key);
    }
}
