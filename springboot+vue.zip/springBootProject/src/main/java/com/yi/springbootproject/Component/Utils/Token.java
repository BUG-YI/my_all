package com.yi.springbootproject.Component.Utils;

import java.util.UUID;

public class Token {
    public static String createToken(Long userId){
        return userId+"_"+ UUID.randomUUID().toString().replace("-","");
    }

    public static Long getUserIdFromToken(String token){
        if ((token==null)||!token.contains("_")){
            return null;
        }
        try{
            return Long.parseLong(token.split("_")[0]);
        }catch (NumberFormatException e){
            return null;
        }
    }
}
