package com.yi.springbootproject.Controller;

import com.yi.springbootproject.Service.MovieInfoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class MovieInfoController {
    private final MovieInfoService movieInfoService;

    public MovieInfoController(MovieInfoService movieInfoService) {
        this.movieInfoService = movieInfoService;
    }

    @GetMapping("/movieInfo")
    public ResponseEntity<?> movieInfoAll(){
        return new ResponseEntity<>(movieInfoService.movieInfoAll(), HttpStatus.OK);
    }

    @GetMapping("/mav")
    public ResponseEntity<?> tMovie(@RequestParam String type){
        try{
            return new ResponseEntity<>(movieInfoService.tMovie(type),HttpStatus.OK);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}