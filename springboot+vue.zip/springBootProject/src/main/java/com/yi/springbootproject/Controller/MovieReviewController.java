package com.yi.springbootproject.Controller;

import com.yi.springbootproject.Service.MovieReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/api")
@CrossOrigin("*")
public class MovieReviewController {
    private final MovieReviewService movieReviewService;

    public MovieReviewController(MovieReviewService movieReviewService) {
        this.movieReviewService = movieReviewService;
    }

    @GetMapping("/allRe")
    public ResponseEntity<?> movieReviewAll(@RequestParam Long movieId){
        System.out.println(movieReviewService.allReview(movieId));
        System.out.println();
        return new ResponseEntity<>(movieReviewService.allReview(movieId), HttpStatus.OK);
    }
}
