package com.yi.springbootproject.Controller;

import com.yi.springbootproject.Service.SonReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/api")
@CrossOrigin("*")
public class SonReviewController {
    private final SonReviewService sonReviewService;

    public SonReviewController(SonReviewService sonReviewService) {
        this.sonReviewService = sonReviewService;
    }
    @GetMapping("/sonRe")
    public ResponseEntity<?> backSonReview(@RequestParam String parentMail){
        return new ResponseEntity<>(sonReviewService.sonReviewList(parentMail), HttpStatus.OK);
    }
}
