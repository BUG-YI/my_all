package com.yi.springbootproject.Controller;

import com.yi.springbootproject.Entity.User;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.yi.springbootproject.Service.UserService;
import com.yi.springbootproject.Component.Utils.Email;

import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class UserController {
    private final UserService userService;
    private final Email email;
    private final RedisTemplate<String,Object> redisTemplate;

    public UserController(UserService userService, Email email, RedisTemplate<String, Object> redisTemplate) {
        this.userService = userService;
        this.email = email;
        this.redisTemplate = redisTemplate;
    }

    @GetMapping("/user")
    public ResponseEntity<?> User(){
        return new ResponseEntity<>(userService.getUser(), HttpStatus.OK);
    }

    @GetMapping("/req/verity")
    public ResponseEntity<?>requestVerity(
            @RequestParam String toEmail
    ){
        try {
            String s = email.sendEmail(toEmail);
            System.out.println("yzm:"+s);
            redisTemplate.opsForValue().set("verity",s,2000, TimeUnit.SECONDS);
            redisTemplate.opsForValue().set("email",toEmail,2000, TimeUnit.SECONDS);
            return new ResponseEntity<>("注意查收验证码",HttpStatus.OK);
        } catch (Exception e) {
//            throw new RuntimeException(e);
            return ResponseEntity.badRequest().body("获取失败");
        }
    }

    @PostMapping("/user/add")
    public ResponseEntity<?> receiveUser(
            @RequestBody User user,
            @RequestParam String verity
    ){
//        System.out.println(redisTemplate.opsForValue().get("verity"));
//        System.out.println(redisTemplate.opsForValue().get("email"));
        ResponseEntity<String> body = ResponseEntity.badRequest().body("信息有误！");
        if (user.getUsername()==null||user.getUsername().trim().isEmpty())return body;
        if (user.getPassword()==null||user.getPassword().trim().isEmpty())return body;
        if (verity==null||verity.trim().isEmpty())return body;
        if (!user.getUsername().equals(redisTemplate.opsForValue().get("email")))return body;
        if(!verity.equals(redisTemplate.opsForValue().get("verity")))return body;
        Boolean user1 = userService.addUser(user);
//        System.out.println("usr1:"+user1);
//        System.out.println("user:"+user);
        if (user1){
            return new ResponseEntity<>("注册成功",HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/user/check")
    public ResponseEntity<?> checkUser(
            @RequestParam String username,
            @RequestParam String password,
            @RequestParam String verity
    ){
        System.out.println(username+password);
        ResponseEntity<String> body = ResponseEntity.badRequest().body("输入信息有误！");
//        if (user==null)return body;
//        if (user.getUsername()==null||user.getUsername().isEmpty())return body;
//        if (user.getPassword()==null||user.getPassword().isEmpty())return body;
        if(username==null||username.isEmpty())return body;
        if (password==null||password.isEmpty())return body;
        if(verity.isEmpty())return body;
        if (!verity.equals(redisTemplate.opsForValue().get("verity")))return body;
        Boolean b = userService.checkUser(username,password);
        if (b){
            return new ResponseEntity<>("登录成功",HttpStatus.OK);
        }
        
        return ResponseEntity.badRequest().body("登录失败");
    }

}
