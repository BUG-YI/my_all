package com.yi.springbootproject.Controller;

import com.yi.springbootproject.Entity.UserData;
import com.yi.springbootproject.Repository.UserDataRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class UserDataController {
    private final UserDataRepository userDataRepository;

    public UserDataController(UserDataRepository userDataRepository) {
        this.userDataRepository = userDataRepository;
    }
    @GetMapping("/userData")
    public ResponseEntity<?> getUserData(@RequestParam String email){
        Optional<UserData> byUserEmail = userDataRepository.findByEmail(email);
        return new ResponseEntity<>(byUserEmail, HttpStatus.OK);
    }

    @PostMapping("/userDataUpdate")
    public ResponseEntity<?> userDataUpdate(@RequestBody UserData user) {
        System.out.println(user);
        Optional<UserData> byEmail = userDataRepository.findByEmail(user.getEmail());
        if (user.getEmail().isEmpty()) return new ResponseEntity<>("用户不存在", HttpStatus.BAD_REQUEST);
        if (byEmail.isEmpty()) return new ResponseEntity<>("用户不存在", HttpStatus.BAD_REQUEST);
        UserData updateUser = byEmail.get();

        if (user.getUsername() != null && !user.getUsername().isEmpty()) {
            updateUser.setUsername(user.getUsername().trim());
        }

        if (user.getGender() != null && !user.getGender().isEmpty()) {
            updateUser.setGender(user.getGender().trim());
        }

        if (user.getSignature() != null && !user.getSignature().isEmpty()) {
            updateUser.setSignature(user.getSignature().trim());
        }

        if (user.getUserPicture() != null && !user.getUserPicture().isEmpty()) {
            updateUser.setUserPicture(user.getUserPicture().trim());
        }

        if (user.getTel()!=null&&!user.getTel().isEmpty()){
            updateUser.setTel(user.getTel().trim());
        }
        userDataRepository.save(updateUser);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
