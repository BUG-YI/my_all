package com.yi.springbootproject.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Data
@Table(name = "movie")
public class MovieInfo {
    @Id
    private Long id;

    @Column(unique = true)
    private String name;

    @Column
    private String img;

    @Column
    private String type;

    @Column
    private String introduction;

    @Column
    private String actor;

    @Column
    private String director;

    @PrePersist
    public void setId(){
        this.id= Instant.now().toEpochMilli();
    }
}
