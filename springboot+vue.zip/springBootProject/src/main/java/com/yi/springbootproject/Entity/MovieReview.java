package com.yi.springbootproject.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "userReview")
public class MovieReview {
    @Id
    private Long id;

    @Column(nullable = false)
    private Long movieId;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String userMail;

    @Column(nullable = false)
    private String review;

    @Column
    private String img;
}
