package com.yi.springbootproject.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "sonReview")
public class SonReview {
    @Id
    private Long id;

    @Column(unique = true,nullable = false)
    private String parentMail;

    @Column(unique = true,nullable = false)
    private String sonMail;

    @Column(nullable = false)
    private String sonReview;
}
