package com.yi.springbootproject.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.Instant;

@Entity
@Data
@Table(name = "users")
public class User {
    @Id
    private Long id;

    @Column(nullable = false,unique = true)
    private String username;

    @Column(nullable = false)
    private String password;


    @PrePersist
    public void setId(){
        this.id=Instant.now().toEpochMilli();
    }
}
