package com.yi.springbootproject.Entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.DynamicUpdate;

import java.time.Instant;

@Data
@Entity
@Table(name = "userdata")
@DynamicUpdate
public class UserData {
    @Id
    private Long id;

    @Column(nullable = false,unique = true)
    private String email;

    @Column
    private String username;

    @Column
    private String userPicture;

    @Column
    private String signature;

    @Column
    private String gender;

    @Column
    private String tel;

    @PrePersist
    public void setId(){this.id= Instant.now().toEpochMilli();}
}
