package com.yi.springbootproject.Repository;

import com.yi.springbootproject.Entity.MovieInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieInfoRepository extends JpaRepository<MovieInfo,Long> {
    @Query("select m from MovieInfo m where m.type like %:type%")
    List<MovieInfo> findByType(String type);
}