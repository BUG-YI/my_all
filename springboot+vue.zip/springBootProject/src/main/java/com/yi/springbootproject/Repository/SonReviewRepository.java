package com.yi.springbootproject.Repository;

import com.yi.springbootproject.Entity.SonReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SonReviewRepository extends JpaRepository<SonReview,Long> {
    @Query("select m from SonReview m where m.parentMail=:parentMail")
    List<SonReview> findByParentMail(String parentMail);
}
