package com.yi.springbootproject.Service;

import com.yi.springbootproject.Entity.MovieInfo;
import com.yi.springbootproject.Repository.MovieInfoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MovieInfoService {
    private final MovieInfoRepository movieInfoRepository;

    public MovieInfoService(MovieInfoRepository movieInfoRepository) {
        this.movieInfoRepository = movieInfoRepository;
    }

    public List<MovieInfo> movieInfoAll(){
        return movieInfoRepository.findAll();
    }

    public List<MovieInfo> tMovie(String type){return movieInfoRepository.findByType(type);}

//    public List<MovieInfo> relateMovie()
}
