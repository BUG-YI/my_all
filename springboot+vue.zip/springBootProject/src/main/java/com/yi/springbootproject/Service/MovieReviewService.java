package com.yi.springbootproject.Service;

import com.yi.springbootproject.Entity.MovieReview;
import com.yi.springbootproject.Repository.MovieReviewRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MovieReviewService {
    private final MovieReviewRepository movieReviewRepository;

    public MovieReviewService(MovieReviewRepository movieReviewRepository) {
        this.movieReviewRepository = movieReviewRepository;
    }

    public List<MovieReview> allReview(Long MovieId){
        return movieReviewRepository.findByMovieId(MovieId);
    }
}
