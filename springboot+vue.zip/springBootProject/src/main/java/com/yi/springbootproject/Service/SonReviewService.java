package com.yi.springbootproject.Service;

import com.yi.springbootproject.Entity.SonReview;
import com.yi.springbootproject.Repository.SonReviewRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SonReviewService {
   private final SonReviewRepository sonReviewRepository;

    public SonReviewService(SonReviewRepository sonReviewRepository) {
        this.sonReviewRepository = sonReviewRepository;
    }

    public List<SonReview>sonReviewList(String parentMail){
        return sonReviewRepository.findByParentMail(parentMail);
    }
}
