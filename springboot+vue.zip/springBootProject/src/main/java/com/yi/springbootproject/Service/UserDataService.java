package com.yi.springbootproject.Service;

import com.yi.springbootproject.Entity.UserData;
import com.yi.springbootproject.Repository.UserDataRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserDataService {
    private final UserDataRepository userDataRepository;

    public UserDataService(UserDataRepository userDataRepository) {
        this.userDataRepository = userDataRepository;
    }

    public Optional<UserData> getUserData(String email){
        return userDataRepository.findByEmail(email);
    }
}
