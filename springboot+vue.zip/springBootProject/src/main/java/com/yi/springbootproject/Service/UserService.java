package com.yi.springbootproject.Service;

import com.yi.springbootproject.Entity.User;
import org.springframework.stereotype.Service;
import com.yi.springbootproject.Repository.UserRepository;

import java.util.List;

@Service
public class UserService {
    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<User> getUser() {
        return userRepository.findAll();
    }

    public Boolean addUser(User user) {
        if (user.getUsername()==null||user.getUsername().trim().isEmpty()){return false;}
        User byUsername = userRepository.findByUsername(user.getUsername());
        if (byUsername == null||byUsername.getUsername().trim().isEmpty()) {
            userRepository.save(user);
            return true;
        }
        return false;
    }

    public Boolean checkUser(String email,String passwd){
        User byUsername = userRepository.findByUsername(email);
        if (byUsername==null||byUsername.getUsername().isEmpty())return false;

        return byUsername.getPassword().equals(passwd);
    }
}