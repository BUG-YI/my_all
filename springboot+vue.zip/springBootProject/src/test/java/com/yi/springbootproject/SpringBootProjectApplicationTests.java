package com.yi.springbootproject;

import com.yi.springbootproject.Configuraton.RedisConfig;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.redis.core.RedisTemplate;


class SpringBootProjectApplicationTests {


    @Test
    public void contextLoads() {

    }
}
