<template>
    <Header/>
    <div class=" html-body">
        <router-view />
         <!-- <t/> -->
    </div>
    <!-- <t/> -->
</template>
<script setup>
import Header from './components/Header.vue';
import request from './assets/js/RequsetAxios';
import t from './components/text/t.vue';

import{ref,provide} from 'vue'

const getUserList = async ()=>{
    const res = await request.get('/api/user')
    console.log(res);
}
const movieAll = ref([])
const getMovieList= async()=>{
    movieAll.value=[]
    const res = await request.get('/api/movieInfo');
    // console.log(res);
    for(const o of res){
        movieAll.value.push(o)
        // console.log(o);
    }
}
getMovieList()
// console.log(movieAll);
provide('movieData',movieAll)

</script>
<style>
*{
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
body{
    background-image: url("http://cdn-hsyq-static.shanhutech.cn/bizhi/staticwp/202112/9bb730ab0e58d029c9af9170dd0a823f--2378667832.jpg");
    background-size: cover;
    /* width: 100vw; */
    min-height: 750px;
    overflow: hidden;
}
.html-body{
    margin: 42px 0 0 0 ;
    padding: 28px 0 0 0;
    width: 100vw;
    height: 95vh;
}
</style>