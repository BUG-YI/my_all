import axios from 'axios';

//request
const request = axios.create({
    baseURL:'http://localhost:8080',
    timeout:8000,
    headers: {
    'Content-Type': 'application/json;charset=utf-8' // 预设默认请求头，避免headers为空
    },
    method:'get'
})
request.interceptors.request.use((config)=>{
    if(!config) config={}
    if(!config.headers) config.headers={}
    config.headers.token = localStorage.getItem('token')||'1'
    return config
    },
    (err)=>{
        console.error('请求拦截器出错：', err.message);
        return Promise.reject(err);
    }
)

request.interceptors.response.use(
    (res)=>{return res.data},
    (err)=>{
        console.log('requset data false:'+ err.message);
        return Promise.reject(err)
    }
)

export default request;