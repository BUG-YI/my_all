<template>
    <header>
        <div class="header-log">
            <img src="../assets/img/logo.png" width="60" alt="logo">
            <p>联合影院</p>
        </div>
        <div>
            <ul>
            <!-- <li @click="getOption(option)" v-for="(option,index) of headerOptionTitle" :key="index">{{ option }}</li> -->
                <li><router-link to="/" class="router-lin">首页</router-link></li>
                <li><router-link to="/category" class="router-lin">分类</router-link></li>
                <li><router-link to="/movie" class="router-lin">电影</router-link></li>
                <li><router-link to="/anime" class="router-lin">动漫</router-link></li>
                <li><router-link to="/variety" class="router-lin">综艺</router-link></li>
            </ul>
        </div>
        <div class="sear">
            <input type="search" class="header-input-search" :placeholder="placeholder">
            <svg class="header-input-search-svg" width="35" height="35" view-box="0 0 36 36" fill="none" stroke="black" stroke-width="2.5" stroke-linecap="round" xmlns="http://www.w3.org/2000/svg">
                <circle cx="13" cy="15" r="8"/>
                <line x1="19" y1="21" x2="25" y2="27"/>
            </svg>
        </div>
        <div>
            <router-link to="/usermanage" v-if="!islogin">
                <img class="header-user-picture" :src="userPicture" width="60" alt="userPicture" title="点击管理用户">
            </router-link>
            <router-link to="/lrc" v-else>
                <img class="header-user-picture" :src="userPicture" width="60" alt="userPicture" title="点击管理用户">
            </router-link>
        </div>
    </header>
</template>
<script setup>
import {ref,defineEmits} from 'vue';
import userImg from '../assets/img/img.png'

    const islogin=true
    // const headerOptionTitle=['首页','分类','电影','动漫','综艺','其他'];
    const userPicture=ref(userImg);
    const placeholder=ref('搜索');
    const emit = defineEmits(['headerOption']);
    
</script>
<style src="../assets/css/Header.css" scoped></style>