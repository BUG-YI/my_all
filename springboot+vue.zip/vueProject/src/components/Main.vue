<template>
    <main>
         <component :is="defaultComponent"></component>
    </main>
</template>
<script setup>
import { computed } from 'vue';
import Index from './main/Index.vue';
import Category from './main/Category.vue';
import Movie from './main/Movie.vue';
import Variety from './main/Variety.vue';
import Anime from './main/Anime.vue';
import Devel from './utils/Devel.vue';

const headerOption ={
    '首页':Index,
    "电影":Movie,
    '分类':Category,
    '动漫':Anime,
    '综艺':Variety,
    '其他':Devel
}
const {headerO} = defineProps({
    headerO:{
        type:[String],
        default:''
    }
})
const defaultComponent = computed(()=>{
    if (!headerO) return Index;
    return headerOption[headerO] ? headerOption[headerO]:Index
})

</script>
<style src="../assets/css/Main.css" scoped></style>