<template>
    <div class="user-manage-main">
        <aside>
            <ul>
                <li @click="aActive($event,index)" v-for="(asided,index) in asideL" :key="index" class="aside-li">{{ asided }}</li>
            </ul>
        </aside>
        <component :is="componentS[vueComponent]"/>

    </div>
</template>
<script setup>
import MoreSetting from './userManage/MoreSetting.vue'
import MovieHistory from './userManage/MovieHistory.vue'
import UserManageSelf from './userManage/UserManageSelf.vue'
import {onMounted, ref} from 'vue'
    const vueComponent=ref(0)
    const componentS=[UserManageSelf,MovieHistory,MoreSetting]
    const asideL=['用户管理','观影历史','更多设置']
    function aActive(event,index){
        const liList=document.querySelectorAll('.aside-li')
        liList.forEach(res=>{
            res.classList.remove('active')
        })
        event.currentTarget.classList.add('active')
        vueComponent.value=index
    }
    onMounted(()=>{
        document.querySelectorAll('.aside-li')[0].classList.add('active')
        componentS[0]=UserManageSelf
    })
</script>
<style src="../assets/css/UserManage.css" scoped></style>