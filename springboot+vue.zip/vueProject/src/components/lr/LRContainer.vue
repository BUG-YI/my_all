<template>
    <main>
        <!-- <div class="lrc-QR"> -->

            <img class="lrc-QR" src="http://localhost:8080/api/createQRC?content=感谢使用联合影院扫描登录" alt="二维码">
        <!-- </div> -->
        <div class="lrc-divider"></div>
        <form @submit.prevent="clickSubmit">
            <Login @ischange="handleChild" v-if="islogin"/>
            <Register @ischange="handleChild" v-else/>
            
        </form>
    </main>
</template>
<script setup>

import Login from './Login.vue';
import Register from './Register.vue';
import { ref } from 'vue';
    const islogin=ref(true)
    // const isregister=ref(false)
    const handleChild=(data)=>{
        islogin.value=data.islogin
        // isregister.value=data.isregister
    }

</script>
<style src="../../assets/css/lr/LRContainer.css" scoped></style>