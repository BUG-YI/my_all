<template>
    <div class="lrc-notQR">
        <h1>Login</h1>
        <i @click="clickH" class="fa-regular fa-circle-question lrc-notQR-i" title="help" ref="ishlep"></i>
        <textarea v-if="showTextarea" class="lrc-notQR-p" readonly @click.stop>提示：
    密码长度需大于8，小于64</textarea>
        <div class="lrc-notQR-input-box">
            <input v-model="email" type="email" placeholder="email">
            <i class="fa-regular fa-envelope lrc-notQR-input-i"></i>
        </div>
        <div class="lrc-notQR-input-box">
            <input v-model="passwd" type="password" placeholder="password">
            <i class="fa-solid fa-key lrc-notQR-input-i"></i>
        </div>
        <div class="lrc-notQR-verity">
            <input v-model="verity" type="text" placeholder="verity">
            <i class="fa-solid fa-list-check lrc-notQR-input-i"></i>
            <p @click="clickVerity">{{ countdown }}</p>
        </div>
        <button @click="clickSubmit" type="submit">login</button>
        <div class="lrc-notQR-FS">
            <p>forget</p>
            <p @click="changeC" class="lrc-notQR-FS-r">sign up</p>
        </div>
        <Message v-if="ismess" :d="d" />
    </div>
</template>
<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue';
import Message from '../utils/Message.vue';
import request from '@/assets/js/RequsetAxios';
import router from '@/router';

const showTextarea = ref(false)
const ishlep = ref(null)
const email = ref('')
const verity = ref('')
const passwd = ref('')
const ismess = ref(false)
const d = ref(null)
const setT = ref(null)
const countdownSetInterval=ref(null)
const countdown=ref("verity")

const clickH = () => {
    showTextarea.value = !showTextarea.value
}
const listenH = (event) => {
    if (ishlep.value && !ishlep.value.contains(event.target)) {
        showTextarea.value = false
    }
}
onMounted(() => {
    document.addEventListener('click', listenH)
})
onUnmounted(() => {
    document.removeEventListener('click', listenH)
    if (setT.value) { clearTimeout(setT.value) }
})

const epv = computed(() => {
    if (email.value.trim().length <= 0) { return false }
    if (passwd.value.trim().length < 8) { return false }
    if (verity.value.trim().length <= 0) { return false }
    return true
})
const clickSubmit = async() => {
    if(setT.value){
        clearTimeout(setT.value)
    }
    if (!epv.value) {
        d.value = "输入信息有误,请检查"
        ismess.value = true
        setT.value = setTimeout(() => {
            ismess.value = false
        }, 2000)
        return
    }
    try{
        const a=await request({
            url: `/api/user/check?verity=${verity.value}`,
            method: 'get',
            params: {
                username: email.value,
                password: passwd.value
            }
        })
        ismess.value=true
        console.log(a);
        d.value=a
        setT.value=setTimeout(()=>{
            ismess.value=false
            d.value=''
        },2000)
    }catch(err){
        ismess.value=true
        // console.log('err:',err);
        d.value='登录失败'
        setT.value=setTimeout(()=>{
            ismess.value=false
            d.value=''
        },2000)
    }
}

const emit = defineEmits(['ischange'])

const changeC = () => {
    if (setT.value||countdownSetInterval.value) {
        clearTimeout(setT.value)
        clearInterval(countdownSetInterval.value)
        setT.value = null
        countdownSetInterval.value=null
    }
    emit('ischange', { islogin: false })
    // , isregister: true
}

const clickVerity=async(event)=>{
    event.preventDefault()
    if(countdown.value>0){
        ismess.value=true
        d.value='请等待倒计时结束，再获取'
        setT.value=setTimeout(()=>{
            ismess.value=false
            d.value=''
        },2000)
        return
    }
    console.log(email.value);
    countdown.value=120
    countdownSetInterval.value=setInterval(()=>{
        countdown.value--
        if(countdown.value<=0){
            countdown.value='verity'
        }
    },1000)

    try{
        const a=await request.get(`/api/req/verity?toEmail=${email.value}`)
        console.log(a);
        ismess.value=true
        d.value=a
        setT.value=setTimeout(()=>{
            ismess.value=false
            d.value=''
        },2000)
    }catch(err){
        ismess.value=true
        d.value='验证码获取失败'
        setT.value=setTimeout(()=>{
            ismess.value=false
            d.value=''
        },2000)
    }
}
</script>
<style src="../../assets/css/lr/Login.css" scoped></style>