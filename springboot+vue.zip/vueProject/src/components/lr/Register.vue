<template>
    <div class="lrc-notQR">    
        <h1>Register</h1>
        <i @click="clickH" class="fa-regular fa-circle-question lrc-notQR-i" title="help" ref="ishlep"></i>
        <textarea v-if="showTextarea" class="lrc-notQR-p" readonly @click.stop>提示：
    密码长度需大于8，小于64</textarea>
        <div class="lrc-notQR-input-box">
            <input v-model="email" type="email" placeholder="email">
            <i class="fa-regular fa-envelope lrc-notQR-input-i"></i>
        </div>
        <div class="lrc-notQR-input-box">
            <input v-model="passwd" type="password" placeholder="password">
            <i class="fa-solid fa-key lrc-notQR-input-i"></i>
        </div>
        <div class="lrc-notQR-input-box">
            <input v-model="passwdT" type="password" placeholder="password again">
            <i class="fa-solid fa-key lrc-notQR-input-i"></i>
        </div>
        <div class="lrc-notQR-verity">
            <input v-model="verity" type="text" placeholder="verity">
            <i class="fa-solid fa-list-check lrc-notQR-input-i"></i>
            <p @click="clickVerity">{{ countdown }}</p>
        </div>
        <button @click="clickSubmit" type="submit">Register</button>
        <div class="lrc-notQR-FS" style="display: block;">
            <p @click="changeC" class="lrc-notQR-FS-r">Have Account ?</p>
        </div>
        <Message v-if="ismess" :d="d"/> 
    </div>
</template>
<script setup>
import { computed, onMounted, onUnmounted, ref } from 'vue';
import Message from '../utils/Message.vue';
import request from '@/assets/js/RequsetAxios';
import router from '@/router';

    const showTextarea=ref(false)
    const ishlep=ref(null)
    const email=ref('')
    const verity=ref('')
    const passwd=ref('')
    const passwdT=ref('')
    const ismess=ref(false)
    const d=ref(null)
    const setT=ref(null)
    const countdown=ref('verity')
    const countdownSetInterval=ref(null)

    const clickH=()=>{
        showTextarea.value=!showTextarea.value
    }
    const listenH=(event)=>{
        if(ishlep.value&&!ishlep.value.contains(event.target)){
            showTextarea.value=false
        }
    }
    onMounted(()=>{
        document.addEventListener('click',listenH)
    })
    onUnmounted(()=>{
        document.removeEventListener('click',listenH)
        if(setT.value){clearTimeout(setT.value)}
    })

    const epv=computed(()=>{ 
        if(email.value.trim().length<=0){return false}
        if(passwd.value.trim().length<8){return false}
        if(passwdT.value.trim().length<8){return false}
        if(passwd.value!=passwdT.value){return false}
        if(verity.value.trim().length<=0){return false}
        return true
    })
    const clickSubmit=()=>{
        clearTimeout(setT.value)
        console.log(epv.value);
        if(!epv.value){
            d.value="输入信息有误,请检查"
            ismess.value=true
            setT.value=setTimeout(()=>{
                ismess.value=false
            },2000)
            return
        }
        if(epv.value){
            handleLogin()
        }

    }
    const handleLogin=async()=>{
        if(setT.value){
            clearTimeout(setT)
        }
        try{
            const a=await request({
                url: `/api/user/add?verity=${verity.value}`,
                method: 'post',
                data: {
                    username: email.value,
                    password: passwd.value
                }
            })
            console.log(email.value,'and',passwd.value);
            ismess.value=true
            d.value=a+'将跳转至登录页面...'
            setT.value=setTimeout(()=>{
                ismess.value=false
            },2000)
            if(a==='注册成功'){
                setT.value=setTimeout(()=>{
                    changeC()
                },2000)
            }

        }
        catch(error){
                ismess.value=true
            d.value="注册失败，输入信息有误"
            // d.value=error
            setT.value=setTimeout(()=>{
                ismess.value=false
            },2000)
        }
    }
    
    const emit=defineEmits(['ischange'])
    const changeC=()=>{
        if(setT.value){
            clearTimeout(setT.value)
            setT.value=null
        }
        emit('ischange',{islogin: true})
    }

    const clickVerity=async(event)=>{
        event.preventDefault()
        if(setT.value){
            clearTimeout(setT.value)
            setT.value=null
        }
        if(countdown.value>0){
            ismess.value=true
            d.value="等待时间结束再点击"
            setT.value=setTimeout(()=>{
                d.value=''
                ismess.value=false
            },2000)
            return
        }
        try{
            const a=await request.get(`/api/req/verity?toEmail=${email.value}`)
            console.log(a);
            countdown.value=20
            ismess.value=true
            d.value=a
            setT.value=setTimeout(()=>{
                d.value=''
                ismess.value=false
            },2000)
            countdownSetInterval.value=setInterval(()=>{
                countdown.value--
                if(countdown.value<=0){
                    countdown.value="verity"
                    clearInterval(countdownSetInterval.value)
                }
            },1000)
        }catch(err){
            ismess.value=true
            d.value="请先输入相关信息"
            setT.value=setTimeout(()=>{
                ismess.value=false
                d.value=''
            },1000)
        }
    }
    onUnmounted(()=>{
        clearInterval(countdownSetInterval.value)
    })
</script>
<style src="../../assets/css/lr/Login.css" scoped></style>