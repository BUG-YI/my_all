<template>
<main >
    <div class="box-place" v-if="animes.length>0">
        <MovieBox v-for="value in mdata" :key="value.id" :mo-name="value"/>
        <div style="min-width: 100vw;display: flex;justify-content: center" ">
            <BackPage @click="subtractM" title="上一页"/>
            <BackPage @click="addM" title="下一页"/>
        </div>
    </div>
     <div class="box-place" v-else>
        <NoMoviePlacehodler/>
    </div>

</main>
</template>
<script setup>
import request from '@/assets/js/RequsetAxios';
import BackPage from '../utils/BackPageNext.vue';
import {computed, ref, watch} from 'vue'
import MovieBox from '../utils/MovieBox.vue';
import NoMoviePlacehodler from '../utils/NoMoviePlacehodler.vue';

const animes=ref([])
const getM=async ()=>{
    const anime=await request.get('/api/mav?type=动漫')
    animes.value=anime
}
getM()
const mdata=ref([])
const movieL =computed(()=>{
     if(animes.value.length<12)return 0
     return Math.ceil(animes.value.length/12)
})
watch(animes,()=>{
    if(!movieL)return
    mdata.value=animes.value.slice(0,12)
},{
    immediate:true,
    deep:true
})
const cou=ref(0)
function addM(){
    if(cou.value<0)return
    if(cou.value<movieL.value){
        cou.value++
        mdata.value=animes.value.slice(12*cou.value,12+cou.value*12)}
}
function subtractM(){
    if(cou.value>=movieL.value)return
    
    if(cou.value>-1){
        cou.value--
        mdata.value=animes.value.slice(12*cou.value,12+12*cou.value)}
}
</script>
<style src="../../assets/css/main/Movie.css" scoped></style>