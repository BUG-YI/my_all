<template>
    <main>
        <CategoryTitle/>
        <div class="box-place" v-if="movieL>0">
            <MovieBox v-for="movie in slicedArr" :moName="movie"/>
            <div style="min-width: 100vw;display: flex;justify-content: center" ">
                <BackPage @click="downMovie" title="上一页"/>
                <BackPage @click="addMovie" title="下一页"/>
            </div>
        </div>
        <div v-else>
            <NoMoviePlacehodler/>
        </div>
        
    </main>
</template>
<script setup>
import CategoryTitle from './CategoryTitle.vue';
import MovieBox from '../utils/MovieBox.vue';
import RequsetAxios from '../../assets/js/RequsetAxios';
import { computed, ref, watch, } from 'vue';
import NoMoviePlacehodler from '../utils/NoMoviePlacehodler.vue';
import BackPage from '../utils/BackPageNext.vue';

const movies=ref([])
const allMovie=async () =>{
    const res= await RequsetAxios.get('/api/movieInfo')
    movies.value=res
}
allMovie()
const movieL=computed(()=>{
    if(movies<12)return 0
    return Math.ceil(movies.value.length/12)
})
const slicedArr=ref([])
watch(movies,()=>{
    movieL

    slicedArr.value=movies.value.slice(0,12)
    // console.log(movieL.value);
},{
    immediate:true,
    deep:true
})
const cou=ref(0)
function addMovie(){
    if(cou.value<0)return
    if(cou.value<movieL.value-1){
        cou.value++
        slicedArr.value=movies.value.slice(12*cou.value,12+12*cou.value)
        // console.log('+',cou.value);
    }
}
function downMovie(){
    if (cou.value<=0)return
    if(cou.value<movieL.value){
        cou.value--
        // console.log(cou.value);
        slicedArr.value=movies.value.slice(12*cou.value,12+12*cou.value)
    }
}
</script>
<style src="../../assets/css/main/Category.css" scoped></style>