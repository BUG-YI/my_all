<template>
    <div>
        <ul v-for="(motype,index) in movieType" :key="index">
            <li v-for="(motypei,indexi) in motype" :key="indexi">{{ motypei }}</li>
        </ul>
    </div>
</template>
<script setup>
    const movieType=[['热度','热门','最新','高分',],['资费','免费','会员','付费'],['类型','动作','喜剧','爱情','科幻','冒险','恐怖','动画','战争','悬疑','灾难']]
</script>
<style src="../../assets/css/main/CategoryTitle.css" scoped></style>