<template>
    <main>
        <div class="movie-detail">
            <div class="mvoie-picture">
                <img :src="movieInfo.img" width="500" alt="mvoiePicture" :title="movieInfo.name||'moviePicture'">
            </div>
            <div class="movie-name-introduction">
                <div class="movie-name-keyframe">
                    <h1 :title="movieInfo.name||'moviename'">{{ movieInfo.name||'moviename' }}</h1>
                    <svg class="movie-name-introduction-svg" width="300" height="100" viewBox="0 0 300 300" fill="none" stroke="black" stroke-width="5" stroke-dasharray="20" xmlns="http://www.w3.org/2000/svg">
                        <line x1="-200" y1="5" x2="-200" y2="160"/>
                        <line x1="450" y1="5" x2="450" y2="204"/>
                    </svg>
                </div>
                <h3 title="introduction">内容介绍</h3>
                <p title="introduction">{{ movieInfo.introduction||'介绍加载失败' }}</p>
            </div>
            <div class="movie-diretor-actor" title="director&&actor">
                <h3>导演</h3>
                <p class="p-diretor">{{ movieInfo.director||'directorInfo err' }}</p>
                <h3>演员</h3>
                <p class="p-actor">{{ movieInfo.actor||'actorInfo err' }}</p>
            </div>
        </div>
        <div class="movie-detail-movie-button">
            <div>HD高清</div>
        </div>
        <div class="movie-detail-review">
            <h3>影评</h3>
            <hr style="margin: 15px 0;">
            <div class="movie-detail-review-t">
                <div class="movie-detail-review-t-img">
                    <div>
                        <div class="movie-detail-review-t-img-number" :title="'影视评分'+rating">{{ rating }}</div>
                        <p style="text-align: center;">星级</p>
                    </div>
                </div>
                <div style="width: 100%;">
                    <div class="movie-detail-review-t-user">
                        <div class="movie-detail-review-t-users">
                            <UserReview v-for="(value) in objectList" :user="value" :key="value.id" />
                        </div>
                    </div>
                    <div class="movie-detail-review-t-submit">
                        <input type="text" placeholder="赶快加入评论大军，发表评论吧~">
                        <p>评论</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
</template>
<script setup>
import { useRoute } from 'vue-router';
import { ref } from 'vue';
import request from '@/assets/js/RequsetAxios';
import UserReview from '../utils/UserReview.vue';

    //usrReview对象
    const usrReviewList=ref({
        id:1,
        movieId:'1',
        review:'1',
        userMail:'1'
    })
    const objectList=ref(usrReviewList.value)

    const route=useRoute()
    const movieInfo=ref(JSON.parse(route.query.movieInfo||'{}'))
    // console.log(movieInfo.value);
    const rating=ref(9.1)

    const reqUserReview=async()=>{
        const res=await request.get(`/api/allRe?movieId=${movieInfo.value.id}`)
        objectList.value=res
        return res
    }
    // console.log(reqUserReview.id);
    reqUserReview()

</script>
<style src="../../assets/css/main/Details.css" scoped></style>