<template>
    <main>
        <Index4Row v-for="(title,index) in titles" :key="index" :title="title" :movieList="innerTop[index]"/>
    </main>
</template>
<script setup>
import Index4Row from './Index4Row.vue';
import {ref,inject, watch,} from 'vue';

const titles = ['今日推荐','电影','动漫','综艺'];
const innerTop = ref([])
const movieData=inject('movieData',[])
watch(movieData,(newVal)=>{
    // console.log(newVal);
    // console.log(newVal[0].id);
    innerTop.value=[]
    for(let i=0;i<4;i++){
        const r = newVal.slice(i*3,(i+1)*3)
        innerTop.value.push(r)
    }
    // console.log(innerTop);
},
{ 
    immediate: true, 
    deep: true       
})

</script>
<style scoped>
main{
    padding: 0 0 0 24px;
    width: 100%;
    height: 100%;
    overflow: auto;
}
</style>