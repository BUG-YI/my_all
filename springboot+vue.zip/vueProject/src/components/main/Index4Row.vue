<template>
    <div>
        <div class="index-main-title" v-if="title">{{ title }}</div>
        
        <div class="movie-frame" v-if="movieList.length===0">
            <NoMoviePlacehodler v-for="(three,index) in threeMovie" :key="index" />
        </div>
        <div class="movie-frame" v-else>
            <!-- <MovieBox v-for="(three) in movieList" :key="three['id']" :moName="{id:three.id,img:three.img,type:three.type,introduction:three.introduction}" /> -->
            <MovieBox v-for="(three) in movieList" :key="three['id']" :moName="three" />
        </div>
    </div>
</template>
<script setup>
import MovieBox from '../utils/MovieBox.vue';
import NoMoviePlacehodler from '../utils/NoMoviePlacehodler.vue';
import { defineProps,} from 'vue';
const a=defineProps({
    title:{
        type:String,    
        default:''
    },
    movieList:{
        type:Array,
        default:[]
    }
})
// console.log('123456',a.movieList[0]);

const threeMovie = Array.from({length:3})
</script>
<style src="../../assets/css/main/Index4Row.css" scoped></style>