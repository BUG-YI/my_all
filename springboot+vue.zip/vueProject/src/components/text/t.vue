<template>
    <div class="q">
        <div class="w"></div>
        <div><img :src="report" alt="1" width="12"></div>
    </div>
</template>
<script setup>
    import report from '../../assets/img/report.svg'
</script>
<style scoped>

</style>