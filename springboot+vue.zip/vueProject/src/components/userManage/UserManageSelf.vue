<template>
     <main>
          <div class="user-manage-profile">
               <div class="user-manage-profile-picture"><img :src="userPicture" width="132" alt="tup"></div>
               <div @click="changeUsername" class="user-manage-profile-name" title="修改名昵"  v-if="isShow">{{ user.username }}</div>
               <div v-else>
                    <input v-model="newname" class="user-manage-profile-name" type="text" maxlength="20" placeholder="输入新昵称">
                    <div class="user-manage-profile-name-cs">
                         <div @click="cancelUsername" class="user-manage-profile-name-cs-b">cancel</div><div @click="saveUsername" class="user-manage-profile-name-cs-b">save</div>
                    </div>
               </div>
               <input v-model="user.signature" class="user-manage-profile-input" type="text" placeholder="个性签名..." title="修改个性签名" maxlength="50">
               <!-- <div class="user-manage-profile-hidden" title="更改头像"><p>上传头像</p></div> -->
               <div class="user-manage-profile-hidden"><input @change="loadP" style="opacity: 0;" type="file" id="q"><label for="q">上传头像</label></div>
               <div @click="updateP">123</div>

               <div class="alter" v-if="!ismsg">{{ msg }}</div>
          </div>
          <div class="user-manage-profile-other">
               <div>
                    <h3>性别</h3>
                    <label v-for="(gender,index) in genders" :key="'gender-'+index"><input type="radio" name="gender" :value="gender" v-model="user.gender" @change="changeGender">{{gender}}</label>
               </div>
               <div class="bind-tel">
                    <h3>手机号</h3>
                    <div>
                         <input v-model="telN" type="tel" maxlength="11" placeholder="绑定手机号">
                         <div @click="cancelT" :class="hiddenC">cancel</div>
                         <div @click="telSave" :class="hiddenC">save</div>
                    </div>
               </div>
               <div class="bind-QQ">
                    <h3>QQ</h3>
                    <div>
                         <input type="text">
                    </div>
               </div>
          </div>
     </main>
</template>
<script setup>
     import request from '../../assets/js/RequsetAxios';
     import {computed, onMounted, ref, watch} from 'vue'
     const NUsername=ref('user陈1233333333333333')
     const userPicture=ref('https://www.keaitupian.cn/cjpic/frombd/1/253/3663778712/1545220977.jpg')
     const hiddenC=ref('c')
     const user=ref({
          email:'',
          username:NUsername.value,
          userPicture:userPicture.value,
          signature:'向往自由，无畏向前…',
          gender:'男',
          tel:15648724908
     })
     const newname=ref(null)
     const isShow=ref(true)
     const msg=ref('')
     const ismsg=ref(true)
     const genders=ref(['男','女','不愿透露'])
     const email=ref('1')
     async function userData(){
           user.value=await request.get(`/api/userData?email=${email.value}`)
          //  console.log(user.value);
           telN.value=user.value.tel
     }
     function changeUsername(){
          isShow.value=false
          newname.value=user.value.username
     }
     const calcNameL=computed(()=>{
          return newname.value.trim().length ||0
     })
     function showHiddenBlock(msg1){
          msg.value=''
          msg.value=msg1
          ismsg.value=false
          setTimeout(()=>{
               ismsg.value=true
          },2000)
     }
     async function saveUsername(){
          calcNameL
          if(!calcNameL.value||calcNameL.value<2){
               showHiddenBlock('username is null or length<2')
               return
          } 
          NUsername.value=newname.value
          await request({
               url:'/api/userDataUpdate',
               method:'post',
               data:{
                    email:email.value,
                    username:NUsername.value,
               }
          })
          userData()
          isShow.value=true
          newname.value=''
          showHiddenBlock('修改成功')
     }
     function cancelUsername(){
          isShow.value=true
          newname.value=''
     }
     let changeG=null
     async function changeGender(){
          if(changeG){clearTimeout(changeG)}
          changeG=setTimeout(async ()=>{await request({
               url:"/api/userDataUpdate",
               method:'post',
               data:{
                    email:email.value,
                    gender:user.value.gender
               }
          })},5000)
     }
     let delayF=null
     const cou=ref(0)
     watch(()=>user.value?.signature,(res)=>{
          if(cou.value===0){
               cou.value++
               return
          }
          if(delayF){clearTimeout(delayF)}
          delayF=setTimeout(
               async ()=> {
               request({
                    url:'/api/userDataUpdate',
                    method:'post',
                    data:{
                         email:email.value,
                         signature:res
                    }
               })},5000)
     })
     //头像
     const selectFile=ref('')
     const previewP=ref(null)
     function loadP(event){
          selectFile.value=event.target.files[0]
          if(!selectFile.value)return
          previewP.value=URL.createObjectURL(selectFile.value)
          // console.log(previewP.value);
     }
     async function updateP(){
          const formData=new FormData()
          formData.append('file',selectFile.value)
          formData.append('email',email.value)
          await request({
               url:'/api/userDataUpdate',
               method:'post',
               data:formData
          })
          // console.log(formData.file);
     }

     const telN=ref('')
     const telC=computed(()=>{
          if(telN.value.length!=11)return false
          return true
     })
     async function telSave(){
          telC
          if(!telC.value){
               showHiddenBlock("tel length isn\'t 11")
               return
          }
          // console.log(telC.value);
          await request({
               url:'/api/userDataUpdate',
               method:'post',
               data:{
                    email:email.value,
                    tel:telN.value
               }
          })
     }
     function cancelT(){
          telN.value=user.value.tel
     }
     onMounted(()=>{
          userData()
     })
</script>
<style src="../../assets/css/userManage/UserManageSelf.css" scoped></style>