<template>
        <div>{{title}}</div>
</template>
<script setup>
defineProps({
    title:{
        type:String,
        default:''
    }
})

// const cou=ref(0)
// function addMovie(){
//     if(cou.value<0)return
//     if(cou.value<movieL.value-1){
//         cou.value++
//         slicedArr.value=movies.value.slice(12*cou.value,12+12*cou.value)
//         console.log('+',cou.value);
//     }
// }
// function downMovie(){
//     if (cou.value<=0)return
//     if(cou.value<movieL.value){
//         cou.value--
//         console.log(cou.value);
//         slicedArr.value=movies.value.slice(12*cou.value,12+12*cou.value)
//     }
// }
</script>
<style scoped>
    div{
        margin: 0 auto;
        padding: 9px;
        width: 70px;
        height: 40px;
        cursor: pointer;
        color: rgb(216 208 208 / 50%);
        transition: all 0.3s ease;
    }
    div:hover{
        background-color: rgb(123 89 89 / 86%);
        color: rgb(35 23 23);
    }
</style>