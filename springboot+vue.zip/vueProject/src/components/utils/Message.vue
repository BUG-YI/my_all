<template>
    <div class="message">
        <i class="fa-solid fa-bomb" style="color: red;font-size: 12px;"> warning</i>
        <p>{{ d }}</p>
    </div>
</template>
<script setup>
import {ref} from 'vue';

    defineProps({
        d: String,
        default: ""
    })
</script>
<style src="../../assets/css/utils/Message.css"></style>