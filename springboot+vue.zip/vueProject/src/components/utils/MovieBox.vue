<template>
        <router-link :to="{path:'/details',query: {movieInfo: JSON.stringify(movieIn)}}" style="text-decoration: none;max-height: 32vh;" :title="moName.id">
            <div class="movie-box">
               <img :src="moName.img" alt="moviePicture">
            
                <p>{{moName["id"]}}</p> 
            </div>
        </router-link>
</template>
<script setup>
import { ref } from 'vue';
const props = defineProps({
    moName:{
        type:[String,Number,Array,Object],
        default:''
    },
})
// const movieIn=ref({
//     name:props.moName.name||'',
//     img:props.moName.img||'',
//     type:props.moName.type||'',
//     introduction:props.moName.introduction||''
// })
const movieIn=ref(props.moName)

// console.log(movieIn.value);
</script>
<style src="../../assets/css/utils/MovieBox.css" scoped></style>