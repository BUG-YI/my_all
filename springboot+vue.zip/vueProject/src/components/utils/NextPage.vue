<template>
        <p>下一页</p>
</template>
<style scoped>
    p{
        margin: 0 auto;
        width: 70px;
        cursor: pointer;
        color: rgb(123 89 89 / 86%);
        transition: all 0.3s ease;
    }
    p:hover{
        background-color: rgb(123 89 89 / 86%);
        color: rgb(35 23 23);
    }

</style>