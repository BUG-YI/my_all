<template>
        <div class="movie-box" title="加载失败">
            
                <img :src="placeholderimg" alt="加载失败">
            
            <p>数据加载失败</p>
        
        </div>
</template>
<script setup>
import placeholderimg from '@/assets/img/placeholder.png'
</script>
<style src="../../assets/css/utils/MovieBox.css" scoped></style>