<template>
    <div class="movie-user-review-container">
        <div class="movie-user-review-container-img"><img :src="props.user.img" alt="usrP"></div>
        <div class="movie-user-review-container-NR">
            <h4>{{props.user.username}}</h4>
            <p>{{ props.user.review}}</p>
        </div>
        <div style="position: relative;">
            <div @click="isMore" style="padding: 0 0 22px 80px;" ref="threePoint"><i class="fa-solid fa-ellipsis"></i></div>
            <div class="movie-user-review-container-DM"><i class="fa-solid fa-angle-down"> 更多评论</i></div>
            <div v-if="hiddenM" class="movie-user-review-container-DM-h" @click.stop>
                <div class="movie-user-review-container-DM-i r"><i class="fa-regular fa-heart" ></i>点赞</div>
                <div class="movie-user-review-container-DM-i r"><i class="fas fa-exclamation-triangle" ></i>举报</div>
                <div class="movie-user-review-container-DM-i b"><i class="fa-solid fa-share"></i>分享</div>
            </div>
        </div>
    </div>
    <hr>
</template>
<script setup>
import {onMounted, onUnmounted, ref} from 'vue'

const threePoint=ref(null)

const props=defineProps({
    user:[Object,String,Number],
    default: {
    username: "zhangs",
    img: '#',
    review: "暂无评论",
}
})

const hiddenM=ref(false)
const isMore=()=>{
    hiddenM.value=!hiddenM.value
}
const notMore=(evnet)=>{
    if(threePoint.value&&!threePoint.value.contains(evnet.target)){
        hiddenM.value=false
    }
}
onMounted(()=>{
    document.addEventListener("click",notMore)
})
onUnmounted(()=>{
    document.removeEventListener("click",notMore)
})
</script>
<style src="../../assets/css/utils/UserReview.css"></style>