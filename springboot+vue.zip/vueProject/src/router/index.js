import { createRouter,createWebHashHistory } from "vue-router";

import Index from '@/components/main/Index.vue';
import Anime from "../components/main/Anime.vue";
import Category from "../components/main/Category.vue";
import Movie from "@/components/main/Movie.vue";
import Variety from "@/components/main/Variety.vue";
import Details from "@/components/main/Details.vue";
import UserManage from "@/components/UserManage.vue";
import LRContainer from "../components/lr/LRContainer.vue";
import Login from '@/components/lr/Login.vue';

const routes = [
    // {path:'/',name:"Index",component:()=>{import('@/components/main/Index.vue')}},
    {path:'/',name:'Index',component:Index},
    {path:'/category',name:"Category",component:Category},
    {path:'/movie',name:"Movie",component:Movie},
    {path:'/anime',name:"Anime",component:Anime},
    {path:'/variety',name:"Variety",component:Variety},
    {path:'/details',name:'Details',component:Details},
    {path:'/usermanage',name:'UserManage',component:UserManage},
    {path: '/lrc',name: 'LRContainer',component: LRContainer},
    // {path: '/login',name: 'Login',component: Login}
]

const router = createRouter({
    history:createWebHashHistory(),
    routes
})

export default router;